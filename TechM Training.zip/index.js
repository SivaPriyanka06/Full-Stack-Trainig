let buttonElement=document.createElement("button")
            buttonElement.textContent="submit";
            document.body.appendChild(buttonElement);
            let c=function(){
                document.body.style.background="black";
            }
            buttonElement.addEventListener("click",c);
            let inputElement=document.createElement("input");
            document.body.appendChild(inputElement);
        let logbtn=document.createElement("button");
        document.body.appendChild(logbtn);
        logbtn.textContent="Log";