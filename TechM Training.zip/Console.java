public class Console {
    public static void main(String[] args) {
        if(console==null){
            System.out.println("No console available");
            return;
        }
        String name=Console.readline();
    }
}
