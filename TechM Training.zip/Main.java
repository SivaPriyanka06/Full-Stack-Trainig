class Main {
    int id;
    String n;
 
 
    Main(){
        System.out.println("This is non-parametrized constructor");
    }

    Main(int num , String name){
        id = num;
        n = name;
        System.out.println("Hiii " + n +" your id is " + id);
    }
 
    public static void main(String args[]) {
        Main s1 = new Main();
       //Default constructor use case
        // System.out.println(s1.id);
        // System.out.println(s1.n);

        Main s2 = new Main(102 , "xyz");
    }
}