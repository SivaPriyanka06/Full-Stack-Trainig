abstract class BankAccount{
    String accountHolder;
    double balance;
    BankAccount(String holder,double bal){
        this.accountHolder=holder;
        this.balance=bal;
    }
    abstract void deposit(double amount);
    void showBalance(){
        System.out.println("Balance:$" +balance);
    }
}
class Savings extends BankAccount{
    Savings(String holder,double bal){
        super(holder,bal);
    }
    @Override
    void deposit(double amount){
        balance+=amount;
        System.out.println("Depositrd $" + amount +"in Savings Account");
    }
}
public class Abstraction{
    public static void main(String[] args){
        BankAccount account=new Savings("Sai",1000);
        account.deposit(500);
        account.showBalance();
    }
}