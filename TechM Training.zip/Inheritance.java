class Parent{
    public void p_m(){
        System.out.println("I am a parent class method");
    }
}
 
//main - child class
public class Inheritance extends Parent
{
    public void c_m(){
        System.out.println("I am a child class of parent");
    }
	public static void main(String[] args) {
// 		System.out.println("Hello World");
 
        Inheritance m1 = new Inheritance();
        m1.c_m();
        m1.p_m();
	}
}