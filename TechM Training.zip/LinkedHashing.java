import java.util.Map;
import java.util.LinkedHashMap;
public class LinkedHashing {
    public static void main(String[] args) {
        Map<Integer,String> map=new LinkedHashMap<>();
        map.put(102,"a");
        map.putIfAbsent(101,"b");
        System.out.println(map);
        map.get(10);
        map.keySet();
        map.values();
        map.entrySet();
        map.replace(102,"n");
        System.out.println(map);
    }
}
