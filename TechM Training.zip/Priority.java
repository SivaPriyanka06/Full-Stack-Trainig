import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
public class Priority {
    public static void main(String[] args){
        PriorityQueue<Integer> q=new PriorityQueue<>();
        q.offer(23);
        q.offer(46);
        q.offer(19);
        q.offer(23);
        q.peek();
        q.poll();
        System.out.println(q);
    }
    
}
