public class Linear {
    public static int linearSearch(int[] arr, int target) {

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i; 
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        // Example array
        int[] arr = { 34, 23, 54, 12, 89, 65, 90 };
        // Target value to search
        int target = 54;

        // Calling the linear search function
        int result = linearSearch(arr, target);

        // Checking if target is found
        if (result == -1) {
            System.out.println("Element not found.");
        } else {
            System.out.println("Element found at index: " + result);
        }
    }
}

