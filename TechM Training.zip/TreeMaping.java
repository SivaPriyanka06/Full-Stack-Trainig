import java.util.Map;
import java.util.TreeMap;
public class TreeMaping {
public static void main(String[] args) {
    Map<Integer,String> map=new TreeMap<>();
    map.put(101,"Raju");
    map.put(102,"Ravi");
    map.put(103,"Tillu");
    map.put(101,"Hari");
    System.out.println(map);
    map.remove(102);
    System.out.println(map);
    System.out.println(map.get(103));
    System.out.println(map.keySet());
    System.out.println(map.values());
    System.out.println(map.entrySet());

}
}
