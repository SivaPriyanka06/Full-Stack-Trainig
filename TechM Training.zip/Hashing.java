import java.util.Map;
import java.util.HashMap;
public class Hashing {
    public static void main(String[] args) {
        Map<Integer,String> map=new HashMap<>();
        map.put(102,"Ravi");
        map.put(103,"ram");
        map.put(101,"Raju");
        map.put(104,"rahul");
        map.put(102,"Mihir");
        System.out.println(map);
        System.out.println(map.get(101));
        System.out.println(map.keySet());
        System.out.println(map.values());
        map.remove(102);
    }
}
