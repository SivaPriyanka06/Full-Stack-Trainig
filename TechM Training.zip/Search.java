import java.util.*;
public class Search {
    public static void main(String[] args){
        Scanner s=new Scanner(System.in);
        int a=s.nextInt();
        int [] arr={10,23,57,89,90};
        int n=arr.length;
        int k=0;
        for(int i=0;i<n;i++){
            if(arr[i]==a){
                System.out.println("element found at index"+ i);
                k=1;
                break;
            }
        }
        if(k==0){
            System.out.println("Element not found in array");
        }
    }
}
