let l=document.getElementById("title");
function theme(){
    l.textContent="welcome to AITS";
    l.innerHTML=`<h2 style="color:red"> Hello from AITS</h2>
}