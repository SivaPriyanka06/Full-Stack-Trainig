import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
public class Sets{
    public static void main(String[] args){
        Set<Integer> set=new HashSet<>(10);
       set.add(10);
       set.add(3);
       set.add(5);
       set.add(2);
       set.add(9);
       System.out.println(set);
       set.remove(5);
       System.out.println(set);
    }
}