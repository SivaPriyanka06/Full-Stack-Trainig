

class Student {

    int id;

    String n;
 
    public void set(int num , String name){

        id = num;

        n = name;

    }  

    public void get(){

        System.out.println("id:"+id);

        System.out.println("name : "+n);

    }

    public static void main(String args[]) {

        Student s1 = new Student();

        s1.set(101 , "abc");

        s1.get();


        Student s2 = new Student();

        s2.set(102 , "aabc");

        s2.get();

    }

}

 
