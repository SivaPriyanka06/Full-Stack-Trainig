import java.util.ArrayList; 
class GreaterElement {
    static ArrayList<Integer> nextLargerElement(int[] arr) {
        int n = arr.length;
        ArrayList<Integer> res = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            res.add(-1);
        }
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (arr[j] > arr[i]) {
                    res.set(i, arr[j]);
                    break;
                }
            }
        }
        return res;
    }
    public static void main(String[] args) {
        int[] arr = { 6, 8, 0, 1, 3 , 9 , 7 };
        ArrayList<Integer> res = nextLargerElement(arr);
        for (int x : res) {
            System.out.print(x + " ");
        }
    }
}
 
 
