class Calculator{
    public void add(int a,int b){
        System.out.println("Two number addition: " +(a+b));
    }
    public int add(int a,int b,int c){
        System.out.println("Three number addition:");
        return a+b+c;
    }
}
class OverLoading {
    public static void main(String[] args){
        Calculator c1=new Calculator();
        c1.add(44,20);
        int res=c1.add(33,44,22);
        System.out.println(res);
    }
    
}
