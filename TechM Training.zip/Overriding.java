class M1{
    public void m1(){
        System.out.println("This is a method of m1 class");
    }
}
class M2 extends M1{
    public void m(){
        System.out.println("This is a method of m2 class");
    }
}
class Overriding {
    public static void main(String [] args){
        M1 ob1=new M1();
        ob1.m1();
        M2 ob2=new M2();
        ob2.m();
        M2 ob3=new M2();
        ob3.m();
    }
    
}
