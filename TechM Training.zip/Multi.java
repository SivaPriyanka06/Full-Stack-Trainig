class GrandParent{

    public void gp_m(){

        System.out.println("I am a grand parent class method");

    }

}
 
 
class Parent extends GrandParent{

    public void p_m(){

        System.out.println("I am a parent class method");

    }

}
 
//main - child class

public class Multi extends Parent

{

    public void c_m(){

        System.out.println("I am a child class of parent");

    }

	public static void main(String[] args) {
 
        Multi m1 = new Multi();

        m1.c_m();

        m1.p_m();

        m1.gp_m();


        Parent p1 = new Parent();

        p1.p_m();

        p1.gp_m();

	}

}
 