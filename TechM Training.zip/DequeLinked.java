import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Queue;
import java.util.ArrayDeque;
import java.util.Deque;

public class DequeLinked{
    public static void main(String[] args){
        Deque<Integer>dq=new LinkedList<>();
        dq.offer(1);
        dq.offerFirst(12);
        dq.offerLast(11);
        System.out.println(dq);
        dq.peekFirst();
        dq.peekLast();
        dq.pollFirst();
        dq.pollLast();
    }
}
