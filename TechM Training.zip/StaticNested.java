class outer{
    private static void Outermethod(){
        System.out.println("Inside outer method");
    }
    static class Inner{
        public static void display(){
            System.out.println("Inside innner class method");
            Outermethod();

        }
    }
}
public class StaticNested {
    public static void main(String [] args){
        outer.Inner.display();
    }
    
}
