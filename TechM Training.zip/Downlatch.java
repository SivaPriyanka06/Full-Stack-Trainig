import java.util.concurrent.*;
import javax.security.auth.callback.*;
public class Downlatch {
    public static void main(String[] args) throws InterruptedException{
        CountDownLatch latch=new CountDownLatch(3);
        Runnable worker=()->{
            System.out.println(Thread.currentThread().getName()+"work started");
            try{
                Thread.sleep(200);
                latch.countDown();
           }
           catch(InterruptedException e){
            e.printStackTrace();
           }
        };
        for(int i=0;i<3;i++){
            new Thread(worker).start();
        }
        latch.wait();
        System.out.println("All Threads are Completed");
        
    }
    
}
