import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
public class Sorted{
    public static void main(String[] args){
        SortedSet<Integer> st=new TreeSet<>();
       st.add(10);
       st.add(3);
       st.add(5);
       st.add(2);
       st.add(9);
       System.out.println(st);
       st.remove(3);
       st.size();
       st.first();
       st.last();
       System.out.println(st);
    }
}
