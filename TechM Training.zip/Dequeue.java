import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Queue;
import java.util.ArrayDeque;

public class Dequeue {
    public static void main(String[] args){
        ArrayDeque<Integer>q=new ArrayDeque<>();
        q.add(1);
        q.offer(2);
        q.addFirst(20);
        q.addLast(20);
        q.removeFirst();
        q.removeLast();
        q.offerFirst(20);
        q.offerLast(23);
        q.peekFirst();
        q.peekLast();
        q.pollFirst();
        q.pollLast();

    }
    
}
