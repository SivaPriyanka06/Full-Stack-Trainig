class Outer{
    private String message="Inside outer method";
    void Outermethod(){
    System.out.println("Inside the outer method");
    class Inner{
        void InnerMethod(){
            System.out.println("Inside the inner method");
            System.out.println("outer class message :" +message);
        }
    }
    Inner y=new Inner();
        y.InnerMethod();
}
}
public class MethodLocal{
    public static void main(String [] args){
        Outer x=new Outer();
        x.Outermethod();
    }

}
